import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface GenerateVideoRequest {
  prompt: string;
  sessionId: string;
  generationId: string;
}

const SAMPLE_VIDEOS = [
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { prompt, sessionId, generationId }: GenerateVideoRequest = await req.json();

    if (!prompt || !sessionId || !generationId) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    await supabase
      .from("video_generations")
      .update({ status: "processing" })
      .eq("id", generationId);

    await new Promise(resolve => setTimeout(resolve, 3000));

    const randomVideo = SAMPLE_VIDEOS[Math.floor(Math.random() * SAMPLE_VIDEOS.length)];

    const videoUrl = randomVideo;
    const thumbnailUrl = `https://via.placeholder.com/640x360/1a1a1a/ffffff?text=${encodeURIComponent(prompt.slice(0, 30))}`;

    const { error: updateError } = await supabase
      .from("video_generations")
      .update({
        status: "completed",
        video_url: videoUrl,
        thumbnail_url: thumbnailUrl,
        duration: 30,
        completed_at: new Date().toISOString(),
      })
      .eq("id", generationId);

    if (updateError) {
      throw updateError;
    }

    await supabase
      .from("user_sessions")
      .update({
        generations_count: supabase.rpc("increment", { row_id: sessionId }),
        last_generation_at: new Date().toISOString(),
      })
      .eq("session_id", sessionId);

    return new Response(
      JSON.stringify({
        success: true,
        generationId,
        videoUrl,
        thumbnailUrl,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Video generation error:", error);

    return new Response(
      JSON.stringify({
        error: "Failed to generate video",
        details: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
