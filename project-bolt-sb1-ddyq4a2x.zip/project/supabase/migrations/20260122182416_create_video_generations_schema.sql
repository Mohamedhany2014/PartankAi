/*
  # Text-to-Video Generation Schema

  ## Overview
  This migration creates the database schema for a text-to-video generation application
  with user session tracking and generation history.

  ## New Tables

  ### `video_generations`
  Stores all video generation requests and their results
  - `id` (uuid, primary key) - Unique identifier for each generation
  - `prompt` (text) - User's text prompt for video generation
  - `status` (text) - Generation status: 'pending', 'processing', 'completed', 'failed'
  - `video_url` (text, nullable) - URL to the generated video
  - `thumbnail_url` (text, nullable) - URL to video thumbnail
  - `error_message` (text, nullable) - Error details if generation failed
  - `session_id` (text) - Anonymous session identifier
  - `duration` (integer, nullable) - Video duration in seconds
  - `created_at` (timestamptz) - When the generation was requested
  - `completed_at` (timestamptz, nullable) - When the generation finished

  ### `user_sessions`
  Tracks anonymous user sessions for rate limiting and analytics
  - `id` (uuid, primary key) - Unique session identifier
  - `session_id` (text, unique) - Anonymous session ID
  - `generations_count` (integer) - Number of generations by this session
  - `last_generation_at` (timestamptz, nullable) - Timestamp of last generation
  - `created_at` (timestamptz) - When the session was created

  ## Security
  - Enable RLS on all tables
  - Allow public read access to video_generations (for viewing results)
  - Allow public insert into video_generations (for creating new generations)
  - Allow public upsert on user_sessions (for session tracking)

  ## Notes
  - This is a public application with anonymous users
  - Sessions are tracked client-side with localStorage
  - Rate limiting will be enforced in the application layer
*/

-- Create video_generations table
CREATE TABLE IF NOT EXISTS video_generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prompt text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  video_url text,
  thumbnail_url text,
  error_message text,
  session_id text NOT NULL,
  duration integer,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  CONSTRAINT valid_status CHECK (status IN ('pending', 'processing', 'completed', 'failed'))
);

-- Create user_sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text UNIQUE NOT NULL,
  generations_count integer DEFAULT 0,
  last_generation_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_video_generations_session_id ON video_generations(session_id);
CREATE INDEX IF NOT EXISTS idx_video_generations_created_at ON video_generations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_video_generations_status ON video_generations(status);
CREATE INDEX IF NOT EXISTS idx_user_sessions_session_id ON user_sessions(session_id);

-- Enable Row Level Security
ALTER TABLE video_generations ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for video_generations
-- Allow anyone to view video generations
CREATE POLICY "Anyone can view video generations"
  ON video_generations FOR SELECT
  TO public
  USING (true);

-- Allow anyone to create new video generations
CREATE POLICY "Anyone can create video generations"
  ON video_generations FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow anyone to update video generations (needed for status updates from edge function)
CREATE POLICY "Anyone can update video generations"
  ON video_generations FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- RLS Policies for user_sessions
-- Allow anyone to view their own session
CREATE POLICY "Anyone can view sessions"
  ON user_sessions FOR SELECT
  TO public
  USING (true);

-- Allow anyone to insert sessions
CREATE POLICY "Anyone can create sessions"
  ON user_sessions FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow anyone to update sessions
CREATE POLICY "Anyone can update sessions"
  ON user_sessions FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);