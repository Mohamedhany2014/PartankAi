import { supabase } from './supabase';

const SESSION_KEY = 'video_gen_session_id';

export function getSessionId(): string {
  let sessionId = localStorage.getItem(SESSION_KEY);

  if (!sessionId) {
    sessionId = crypto.randomUUID();
    localStorage.setItem(SESSION_KEY, sessionId);
  }

  return sessionId;
}

export async function initSession(): Promise<void> {
  const sessionId = getSessionId();

  const { data: existing } = await supabase
    .from('user_sessions')
    .select('*')
    .eq('session_id', sessionId)
    .maybeSingle();

  if (!existing) {
    await supabase
      .from('user_sessions')
      .insert({ session_id: sessionId });
  }
}

export async function getSessionData() {
  const sessionId = getSessionId();

  const { data } = await supabase
    .from('user_sessions')
    .select('*')
    .eq('session_id', sessionId)
    .maybeSingle();

  return data;
}
