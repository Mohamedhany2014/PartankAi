import { useState, useEffect, useCallback } from 'react';
import { Video, Sparkles, Play, Tv } from 'lucide-react';
import { supabase } from './lib/supabase';
import { getSessionId, initSession } from './lib/session';
import { VideoPlayer } from './components/VideoPlayer';
import { VideoHistory } from './components/VideoHistory';
import { AdBanner } from './components/AdBanner';
import type { VideoGeneration } from './types/database';

function App() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentVideo, setCurrentVideo] = useState<VideoGeneration | null>(null);
  const [videoHistory, setVideoHistory] = useState<VideoGeneration[]>([]);
  const [showAdModal, setShowAdModal] = useState(false);
  const [adWatchProgress, setAdWatchProgress] = useState(0);
  const [canGenerate, setCanGenerate] = useState(true);

  useEffect(() => {
    initSession();
    loadVideoHistory();

    const subscription = supabase
      .channel('video_updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'video_generations',
          filter: `session_id=eq.${getSessionId()}`,
        },
        (payload) => {
          const updated = payload.new as VideoGeneration;
          setVideoHistory((prev) =>
            prev.map((v) => (v.id === updated.id ? updated : v))
          );
          if (currentVideo?.id === updated.id) {
            setCurrentVideo(updated);
            if (updated.status === 'completed' || updated.status === 'failed') {
              setIsGenerating(false);
            }
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [currentVideo?.id]);

  const loadVideoHistory = async () => {
    const sessionId = getSessionId();
    const { data } = await supabase
      .from('video_generations')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) {
      setVideoHistory(data);
      if (data.length > 0 && !currentVideo) {
        setCurrentVideo(data[0]);
      }
    }
  };

  const startGeneration = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setCanGenerate(false);

    try {
      const sessionId = getSessionId();

      const { data: newGeneration, error: insertError } = await supabase
        .from('video_generations')
        .insert({
          prompt: prompt.trim(),
          session_id: sessionId,
          status: 'pending',
        })
        .select()
        .single();

      if (insertError) throw insertError;

      setCurrentVideo(newGeneration);
      setVideoHistory((prev) => [newGeneration, ...prev]);

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-video`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt.trim(),
          sessionId,
          generationId: newGeneration.id,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to start video generation');
      }

      await loadVideoHistory();
      setPrompt('');
    } catch (error) {
      console.error('Generation error:', error);
      setIsGenerating(false);
    }
  };

  const handleWatchAd = useCallback(() => {
    setShowAdModal(true);
    setAdWatchProgress(0);

    const interval = setInterval(() => {
      setAdWatchProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setShowAdModal(false);
          setCanGenerate(true);
          return 100;
        }
        return prev + 5;
      });
    }, 150);
  }, []);

  const handleSelectVideo = (video: VideoGeneration) => {
    setCurrentVideo(video);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Video className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white">
              AI Video Studio
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Transform your ideas into stunning videos with AI
          </p>
        </header>

        <div className="mb-8">
          <AdBanner size="large" position="Top Banner - Google AdSense" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-gray-800 rounded-xl p-6 shadow-2xl">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-blue-500" />
                Create Your Video
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-gray-300 mb-2 font-medium">
                    Describe your video
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="A serene beach sunset with waves crashing on the shore..."
                    className="w-full px-4 py-3 bg-gray-900 text-white rounded-lg border border-gray-700 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 min-h-[120px] resize-none"
                    disabled={isGenerating}
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={startGeneration}
                    disabled={!prompt.trim() || isGenerating || !canGenerate}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg font-semibold transition-all transform hover:scale-105 disabled:transform-none flex items-center justify-center gap-2"
                  >
                    <Play className="w-5 h-5" />
                    {isGenerating ? 'Generating...' : 'Generate Video'}
                  </button>

                  {!canGenerate && !isGenerating && (
                    <button
                      onClick={handleWatchAd}
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-lg font-semibold transition-all transform hover:scale-105 flex items-center justify-center gap-2 whitespace-nowrap"
                    >
                      <Tv className="w-5 h-5" />
                      Watch Ad to Generate
                    </button>
                  )}
                </div>

                {!canGenerate && !isGenerating && (
                  <p className="text-yellow-500 text-sm text-center">
                    Watch an ad to unlock your next generation
                  </p>
                )}
              </div>
            </div>

            <VideoPlayer generation={currentVideo} isGenerating={isGenerating} />
          </div>

          <div className="space-y-6">
            <AdBanner size="small" position="Sidebar - Google AdSense" />

            <div className="bg-gray-800 rounded-xl p-6 shadow-2xl">
              <h3 className="text-xl font-bold text-white mb-4">Quick Tips</h3>
              <ul className="space-y-3 text-gray-300 text-sm">
                <li className="flex gap-2">
                  <span className="text-blue-500 font-bold">•</span>
                  <span>Be specific and descriptive in your prompts</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-blue-500 font-bold">•</span>
                  <span>Mention camera angles, lighting, and mood</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-blue-500 font-bold">•</span>
                  <span>Include details about subjects and actions</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-blue-500 font-bold">•</span>
                  <span>Videos are generated in high quality</span>
                </li>
              </ul>
            </div>

            <AdBanner size="small" position="Sidebar Bottom - Google AdSense" />
          </div>
        </div>

        <VideoHistory
          generations={videoHistory}
          onSelect={handleSelectVideo}
          selectedId={currentVideo?.id}
        />

        <div className="mt-8">
          <AdBanner size="large" position="Bottom Banner - Google AdSense" />
        </div>
      </div>

      {showAdModal && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl p-8 max-w-md w-full text-center">
            <Tv className="w-16 h-16 text-blue-500 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">
              Please Watch This Ad
            </h3>
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-8 mb-4 h-48 flex items-center justify-center">
              <p className="text-white text-xl font-semibold">
                Advertisement Playing...
              </p>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${adWatchProgress}%` }}
              />
            </div>
            <p className="text-gray-400">
              {adWatchProgress < 100
                ? `${Math.ceil((100 - adWatchProgress) / 5 * 0.15)} seconds remaining...`
                : 'Ad completed! You can now generate.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
