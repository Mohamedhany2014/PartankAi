export interface Database {
  public: {
    Tables: {
      video_generations: {
        Row: {
          id: string;
          prompt: string;
          status: 'pending' | 'processing' | 'completed' | 'failed';
          video_url: string | null;
          thumbnail_url: string | null;
          error_message: string | null;
          session_id: string;
          duration: number | null;
          created_at: string;
          completed_at: string | null;
        };
        Insert: {
          id?: string;
          prompt: string;
          status?: 'pending' | 'processing' | 'completed' | 'failed';
          video_url?: string | null;
          thumbnail_url?: string | null;
          error_message?: string | null;
          session_id: string;
          duration?: number | null;
          created_at?: string;
          completed_at?: string | null;
        };
        Update: {
          id?: string;
          prompt?: string;
          status?: 'pending' | 'processing' | 'completed' | 'failed';
          video_url?: string | null;
          thumbnail_url?: string | null;
          error_message?: string | null;
          session_id?: string;
          duration?: number | null;
          created_at?: string;
          completed_at?: string | null;
        };
      };
      user_sessions: {
        Row: {
          id: string;
          session_id: string;
          generations_count: number;
          last_generation_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          session_id: string;
          generations_count?: number;
          last_generation_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          session_id?: string;
          generations_count?: number;
          last_generation_at?: string | null;
          created_at?: string;
        };
      };
    };
  };
}

export type VideoGeneration = Database['public']['Tables']['video_generations']['Row'];
export type UserSession = Database['public']['Tables']['user_sessions']['Row'];
