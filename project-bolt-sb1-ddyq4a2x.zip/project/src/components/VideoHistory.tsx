import { Clock, Play } from 'lucide-react';
import type { VideoGeneration } from '../types/database';

interface VideoHistoryProps {
  generations: VideoGeneration[];
  onSelect: (generation: VideoGeneration) => void;
  selectedId?: string;
}

export function VideoHistory({ generations, onSelect, selectedId }: VideoHistoryProps) {
  if (generations.length === 0) {
    return (
      <div className="bg-gray-800 rounded-lg p-8 text-center">
        <Clock className="w-12 h-12 text-gray-600 mx-auto mb-4" />
        <p className="text-gray-400">No videos generated yet</p>
        <p className="text-gray-500 text-sm mt-2">Your generation history will appear here</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2">
        <Clock className="w-6 h-6" />
        Recent Generations
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {generations.map((gen) => (
          <button
            key={gen.id}
            onClick={() => onSelect(gen)}
            className={`group relative bg-gray-800 rounded-lg overflow-hidden transition-all hover:scale-105 hover:shadow-xl ${
              selectedId === gen.id ? 'ring-2 ring-blue-500' : ''
            }`}
          >
            <div className="aspect-video bg-gray-900 relative">
              {gen.thumbnail_url ? (
                <img
                  src={gen.thumbnail_url}
                  alt={gen.prompt}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Play className="w-12 h-12 text-gray-600" />
                </div>
              )}
              {gen.status === 'processing' && (
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                  <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              {gen.status === 'completed' && (
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center">
                  <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              )}
            </div>
            <div className="p-3">
              <p className="text-white text-sm font-medium line-clamp-2 text-left">
                {gen.prompt}
              </p>
              <p className="text-gray-500 text-xs mt-1 text-left">
                {new Date(gen.created_at).toLocaleDateString()}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
