import { ExternalLink } from 'lucide-react';

interface AdBannerProps {
  size: 'large' | 'small';
  position?: string;
}

export function AdBanner({ size, position = 'AdSense Banner' }: AdBannerProps) {
  const height = size === 'large' ? 'h-32' : 'h-24';

  return (
    <div className={`bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg ${height} flex items-center justify-center border-2 border-dashed border-gray-700`}>
      <div className="text-center">
        <ExternalLink className="w-8 h-8 text-gray-600 mx-auto mb-2" />
        <p className="text-gray-500 text-sm font-medium">{position}</p>
        <p className="text-gray-600 text-xs mt-1">Advertisement Space</p>
      </div>
    </div>
  );
}
