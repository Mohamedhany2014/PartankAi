import { Play, Download } from 'lucide-react';
import type { VideoGeneration } from '../types/database';

interface VideoPlayerProps {
  generation: VideoGeneration | null;
  isGenerating: boolean;
}

export function VideoPlayer({ generation, isGenerating }: VideoPlayerProps) {
  if (isGenerating) {
    return (
      <div className="w-full aspect-video bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg font-medium">Generating your video...</p>
          <p className="text-gray-400 text-sm mt-2">This may take a few moments</p>
        </div>
      </div>
    );
  }

  if (!generation || !generation.video_url) {
    return (
      <div className="w-full aspect-video bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-700">
        <div className="text-center">
          <Play className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">Your generated video will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div className="relative rounded-lg overflow-hidden shadow-2xl">
        <video
          key={generation.video_url}
          controls
          className="w-full aspect-video bg-black"
          poster={generation.thumbnail_url || undefined}
        >
          <source src={generation.video_url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>

      <div className="flex items-center justify-between bg-gray-800 rounded-lg p-4">
        <div className="flex-1">
          <p className="text-white font-medium mb-1">Generated Video</p>
          <p className="text-gray-400 text-sm line-clamp-1">{generation.prompt}</p>
        </div>
        <a
          href={generation.video_url}
          download
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Download className="w-4 h-4" />
          Download
        </a>
      </div>
    </div>
  );
}
